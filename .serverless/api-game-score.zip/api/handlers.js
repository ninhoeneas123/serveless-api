
const { MongoClient, ObjectId } = require('mongodb');
const bcrypt = require('bcrypt');
const { sign } = require('jsonwebtoken');

require('aws-sdk/lib/maintenance_mode_message').suppress = true;



let connectionInstance

async function connectDatabase() {
    const client = new MongoClient(process.env.MONGODB_CONNECTIONSTRING)
    const connection = await client.connect()

    connectionInstance = connection.db(process.env.MONGODB_DB_NAME)
    return connectionInstance
}

function extractBody(event) {
    if (!event?.body) {
        return {
            statusCode: 400,
            body: JSON.stringify({
                message: 'Missing body'
            })
        }
    }
    return JSON.parse(event.body)
}

async function cryptPassword(password) {
    const saltRounds = 10
    const salt = bcrypt.genSaltSync(saltRounds);
    const hash = bcrypt.hashSync(password, salt);

    return hash
}

async function userIsVality(userName, password) {
    const client = await connectDatabase()
    const collection = await client.collection('users-serveless')
    const user = await collection.findOne({ email: userName })
    const isPasswordValid = await bcrypt.compare(password, user.password)

    if (!user || isPasswordValid === false) {
        return false
    }
    console.log(user)
    return user
}


module.exports.createUser = async (event) => {
    const { name, email, password } = extractBody(event)
    const user = {
        name: name,
        email: email,
        password: await cryptPassword(password)
    }
    const client = await connectDatabase()
    const collection = await client.collection('users-serveless')
    const userData = await collection.insertOne(user)

    return {
        statusCode: 201,
        body: JSON.stringify({
            message: 'User created',
            insertdId: userData.insertedId,
            password: user.password
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    }
}

module.exports.getUsers = async (event) => {
    const client = await connectDatabase()
    const collection = await client.collection('users-serveless')
    const users = await collection.findOne({
        _id: new ObjectId(event.pathParameters.id)
    })
    if (!users) {
        return {
            statusCode: 404,
            body: JSON.stringify({
                message: 'User not found'
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        }
    }
}
module.exports.login = async (event) => {
    const { userName, password } = extractBody(event)
    const isValid = await userIsVality(userName, password)

    if (isValid === false) {
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'UserName or Password is not valid'
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        }
    }

    // const token = sign({ userName, id: isValid._id   }, process.env.JWT_SECRET, {
    //     expiresIn: '1h',
    //     audience:'api-game-score'

    // })

    return {
        statusCode: 200,
        body: JSON.stringify(users),
        headers: {
            'Content-Type': 'application/json'
        }

    }
}
