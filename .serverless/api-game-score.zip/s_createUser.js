
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'joseeneas',
  applicationName: 'api-game-score',
  appUid: 'RmTw0PQlBkVTLf6k16',
  orgUid: 'df8fb6d2-9f3d-4119-a11d-654f1ec0e9f2',
  deploymentUid: 'e3962b0f-a631-4ad9-b80d-a619854cbf14',
  serviceName: 'api-game-score',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'api-game-score-prod-createUser', timeout: 6 };

try {
  const userHandler = require('./api/handlers.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createUser, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}